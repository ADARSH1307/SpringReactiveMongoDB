package com.learning.ReactiveMongodb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactiveMongodbApplicationTests {

	@Test
	void contextLoads() {
	}

}
