package com.learning.ReactiveMongodb.controller;

import com.learning.ReactiveMongodb.model.User;
import com.learning.ReactiveMongodb.repo.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
public class UserController {

    @Autowired
    private UserRepo userRepository;

    @GetMapping("/getusers")
    public Flux<User> getAllUsers() {
        return userRepository.findAll();
    }

    @PostMapping("/postuser")
    public Mono<User> createUser(@RequestBody User user) {
        return userRepository.save(user);
    }

}