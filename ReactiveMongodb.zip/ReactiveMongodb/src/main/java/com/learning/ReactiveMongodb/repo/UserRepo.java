package com.learning.ReactiveMongodb.repo;

import com.learning.ReactiveMongodb.model.User;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;

public interface UserRepo extends ReactiveMongoRepository<User,String> {
}
